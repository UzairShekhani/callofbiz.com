<?php include('./inc/head.php');?>
<?php include('./inc/header.php');?>
<div class="page-body">
    <section class="bg">
        <div class="container">

            <div class="row">
                <div class="col-2">
                    <h2 class="">
                        LOYALITY
                    </h2>
                    <img class="w-100 h-50" src="./assets/images/blog/images.jpg" alt="">
                </div>
                <div class="col-8">
                    <div class="background_pic">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-left">
                                    <h1 class="fontbold-600 text-white">
                                        JOIN</h1>
                                    <h2><b class="text-white">AS</b>
                                        <span class="text">
                                            MEMBER
                                        </span>
                                    </h2>
                                    <p class="f-12 text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                        Est vel impedit quod omnis
                                        commodi velit eius facilis voluptate consequatur </p>
                                </div>
                            </div>
                            <div class="col-md-4">

                            </div>
                            <div class="col-md-4">
                                <div class="text-left">
                                    <h2 class="text-white">
                                        BECOME AS PATNERS
                                    </h2>
                                    <p class="f-12 text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                        Est vel impedit. </p>
                                    <h3 class="text-white">
                                        BECOME NOW
                                    </h3>
                                    <p class="b-1 f-12 text-white">Lorem ipsum dolor, sit amet consectetur adipisicing
                                        elit. Assumenda nulla
                                        repellat.</p>

                                </div>
                                <div class="w-58">
                                    <a href="#" class="btn btn-theme f-14 rounded-pill"><span class="f-12">JOIN
                                            NOW</span></a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-2">
                    <h2>
                        LOYALITY
                    </h2>
                    <img class="w-100 h-50" src="./assets/images/blog/images.jpg" alt="">
                </div>
            </div>
        </div>
    </section>
    <section class="shortest">
        <div class="container">
            <div class="row">
                <div class="col-2">
                    <div class="bg-short">
                        <img src="" alt="">
                        <h4 class="text-white">
                            JOIN US
                        </h4>
                        <p class="text-white font-09">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas fugit
                            repudiandae</p>
                        <a href="#" class="w-75 font-10 btn btn-theme rounded-pill">JOIN US</a>
                    </div>
                </div>
                <div class="col-2">
                    <div class="bg-short">
                        <img src="" alt="">
                        <h4 class="text-white">
                            JOIN AS MEMBER
                        </h4>
                        <p class="text-white font-09">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas fugit
                            repudiandae</p>
                        <a href="#" class="w-75 font-10 btn btn-theme rounded-pill">JOIN US</a>
                    </div>
                </div>
                <div class="col-2">
                    <div class="bg-short">
                        <img src="" alt="">
                        <h4 class="text-white">
                            BECOME A MEMBER
                        </h4>
                        <p class="text-white font-09">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas fugit
                            repudiandae</p>
                        <a href="#" class="w-75 font-10 btn btn-theme rounded-pill">JOIN US</a>
                    </div>
                </div>
                <div class="col-2">
                    <div class="bg-short">
                        <img src="" alt="">
                        <h4 class="text-white">
                            BECOME A PATNERS
                        </h4>
                        <p class="text-white font-09">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas fugit
                            repudiandae</p>
                        <a href="#" class="w-75 font-10 btn btn-theme rounded-pill">JOIN US</a>
                    </div>
                </div>
                <div class="col-2">
                    <div class="bg-short">
                        <img src="" alt="">
                        <h4 class="text-white">
                            INEST NOW </h4>
                        <p class="font-09 text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas fugit repudiandae</p>
                        <a href="#" class="w-75 font-10 btn btn-theme rounded-pill">JOIN US</a>
                    </div>
                </div>
                <div class="col-2">
                    <div class="bg-short">
                        <img src="" alt="">
                        <h4 class="text-white">
                            EXPLORE JOB
                        </h4>
                        <p class="text-white font-09">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas fugit
                            repudiandae</p>
                        <a href="#" class="w-75 font-10 btn btn-theme rounded-pill">JOIN US</a>
                    </div>
                </div>

            </div>
        </div>
    </section>
</div>
<?php include('./inc/footer.php');?>